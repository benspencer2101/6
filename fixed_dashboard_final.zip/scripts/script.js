$(document).ready(function () {
  $.getJSON("api/get_projects.php", function (data) {
    let html = "<table border='1'><tr><th>Name</th><th>City</th></tr>";
    $.each(data, function (index, project) {
      html += "<tr><td>" + project.name + "</td><td>" + project.city + "</td></tr>";
    });
    html += "</table>";
    $("#project-table").html(html);
  }).fail(function () {
    $("#project-table").html("<p style='color:red;'>⚠️ Could not load project data.</p>");
  });
});
